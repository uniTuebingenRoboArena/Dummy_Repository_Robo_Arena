import sys
from PyQt5.QtWidgets import QApplication,QWidget,QLabel
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QImage,QPalette,QBrush

from ArenaButton import ArenaButton



class Window(QWidget):

    def __init__(self,windowWidth,windowHeight):
        self.windowwidth = windowWidth
        self.windowHeight = windowHeight
        super().__init__()
        self.initUI()

    def initUI(self):
        exitbutton = ArenaButton("exitbutton","exit",self)
        playbutton = ArenaButton("playbutton","play", self)
        settingbutton = ArenaButton("settingbutton","setting", self)

        self.l1 = QLabel('Robo Arena',self)
        self.l1.move(int(self.windowwidth/2), int(self.windowHeight/4))
        self.l1.setStyleSheet(
            "font-size:100px;"
            "color:red;"
        )
        oImage = QImage("backgroundimage.jpg")
        sImage = oImage.scaled(QSize(self.windowwidth, self.windowHeight))  # resize Image to widgets size
        palette = QPalette()
        palette.setBrush(QPalette.Window, QBrush(sImage))
        self.setPalette(palette)

        self.setFixedSize(self.windowwidth,self.windowHeight)
        self.setWindowTitle("Robo-Arena-Team")
        self.show()

app = QApplication(sys.argv)
w = Window(1500,1100)

sys.exit(app.exec_())


